import os
import pandas as pd
import numpy as np

print(len(os.listdir("data")))  # first check the number of file

def clean_null_file(file_name: str) -> int:  # Delete empty file
    for item in os.listdir(file_name):
        path = os.path.abspath(file_name)
        file = os.path.join(path, item)
        if os.path.getsize(file) < 3:   # If the size of file less than 3kb, it will be regarded as empty file and deleted
            os.remove(file)
    return len(os.listdir(file_name)) # check the number of file, after processed.


def clean_static_point(file_name: str, col: int) -> int: # Delete data that has not changed significantly
    for item in os.listdir(file_name):
        path = os.path.abspath(file_name)
        file = os.path.join(path, item)
        data = pd.read_json(file)
        ran = max(data.iloc[:, col]) - min(data.iloc[:, col])
        if ran <= 1:  # If range of data less than 1, I delete file
            os.remove(file)
    return len(os.listdir(file_name))

def statistics_null(file_name: str):
    for item in os.listdir(file_name):
        path = os.path.abspath(file_name)
        file = os.path.join(path, item)
        file = pd.read_json(file)
        print(file.isnull().sum())


clean_null_file("data")

 # delete time abnormal data
duration = [int(item.split("_")[1]) for item in os.listdir("data")]
IQR = np.percentile(duration, 75) - np.percentile(duration, 25)
upper = np.percentile(duration, 75) + 1.5 * IQR
lower = np.percentile(duration, 25) - 1.5 * IQR
for item in os.listdir("data"):
    path = os.path.abspath("data")
    file = os.path.join(path, item)
    if int(item.split("_")[1]) > upper or int(item.split("_")[1]) < lower:
        os.remove(file)

statistics_null("data")
print("the number of remaining files is",clean_static_point("data",0))
print("the number of remaining files is",clean_static_point("data",1))
print("the number of remaining files is",clean_static_point("data",2))











