import urllib
import urllib.request


def loadPage(url, filename):
    request = urllib.request.Request(url)
    return urllib.request.urlopen(request).read()


def writePage(html, filename):
    with open(filename, "w") as f:
        f.write(html)
    print("-" * 30)


def Spider(url):
    filename = url.split("/")[-1]
    fullurl = url
    html = loadPage(fullurl, filename)
    str_html = str(html).replace("b\'", "").replace(
        "\'", "").replace("\\n", "\n")
    writePage(str_html, filename)


if __name__ == "__main__":

    url = "http://yang.lzu.edu.cn/data/index.txt"
    Spider(url)
    url_harf = "http://yang.lzu.edu.cn/data/"
    s = 1
    with open("index.txt", "r") as f:
        filenames = f.readlines()
    for i in filenames:
        print(i)
        url_full = url_harf + i.replace('\n', '')
        try:
            Spider(url_full)
        except(Exception):
            print(s)
            s += 1
print("end...")